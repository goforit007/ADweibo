//
//  WeiboFrameModel.m
//  ADweibo
//
//  Created by fad on 14-11-10.
//  Copyright (c) 2014年 fad. All rights reserved.
//

#import "WeiboFrameModel.h"
#import "UserModel.h"


@implementation WeiboFrameModel

-(void)setWeibo:(WeiboModel *)weibo{
    _weibo=weibo;
    //cell宽度
    CGFloat cellW=[UIScreen mainScreen].bounds.size.width;
    //微博背景
    CGFloat BGImageX=0;
    CGFloat BGImageY=0;
    CGFloat BGImageW=cellW;

    //头像
    CGFloat IconImageX=kWeiboCellBorder;
    CGFloat IconImageY=kWeiboCellBorder;
    CGFloat IconImageW=35;
    CGFloat IconImageH=35;
    _weiboIconImageFrame=CGRectMake(IconImageX, IconImageY, IconImageW, IconImageH);
    //昵称
    CGFloat NameLabelX=CGRectGetMaxX(_weiboIconImageFrame)+kWeiboCellBorder;
    CGFloat NameLabelY=kWeiboCellBorder;
    CGSize nameSize=[_weibo.user.name sizeWithFont:kNameUIFont];
    CGFloat NameLabelW=nameSize.width;
    CGFloat NameLabelH=nameSize.height;
    _weiboNameLabelFrame=CGRectMake(NameLabelX,NameLabelY, NameLabelW, NameLabelH);
    
    //时间
    CGFloat TimeLabelX=NameLabelX;
    CGFloat TimeLabelY=CGRectGetMaxY(_weiboNameLabelFrame)+kWeiboCellBorder;
    CGSize timeSize=[_weibo.created_at sizeWithFont:kTImeUIFont];
    CGFloat TimeLabelW=timeSize.width;
    CGFloat TimeLabelH=timeSize.height;
    _weiboTimeLabelFrame=CGRectMake(TimeLabelX,TimeLabelY, TimeLabelW, TimeLabelH);
    //来源
    CGFloat SourceLabelX=CGRectGetMaxX(_weiboTimeLabelFrame)+kWeiboCellBorder;
    CGFloat SourceLabelY=TimeLabelY;
    CGSize SourceLabelSize=[_weibo.source sizeWithFont:kSourceUIFont];
    CGFloat SourceLabelW=SourceLabelSize.width;
    CGFloat SourceLabelH=SourceLabelSize.height;
    _weiboSourceLabelFrame=CGRectMake(SourceLabelX,SourceLabelY, SourceLabelW, SourceLabelH);
    //正文
    CGFloat TextLabelX=kWeiboCellBorder;
    CGFloat TextLabelY=MAX(CGRectGetMaxY(_weiboIconImageFrame), CGRectGetMaxY(_weiboTimeLabelFrame));
    CGSize contentSize=CGSizeMake(BGImageW-2*kWeiboCellBorder, CGFLOAT_MAX);
    CGSize TextSize=[self.weibo.text sizeWithFont:kTTextUIFont constrainedToSize:contentSize];
    CGFloat TextLabelW=TextSize.width;
    CGFloat TextLabelH=TextSize.height;
    _weiboTextLabelFrame=CGRectMake(TextLabelX, TextLabelY, TextLabelW, TextLabelH);
    
    CGFloat BGImageH=CGRectGetMaxY(_weiboTextLabelFrame)+kWeiboCellBorder;
    _weiboBGImageFrame=CGRectMake(BGImageX, BGImageY, BGImageW, BGImageH);
    self.cellH=CGRectGetMaxY(_weiboTextLabelFrame)+kWeiboCellBorder;
}

@end
